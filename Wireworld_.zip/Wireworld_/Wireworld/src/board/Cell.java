package board;

public enum Cell {
    EMPTY, CONDUCTOR, ETAIL, EHEAD
}

