package gui;


import filemanager.exceptions.ComponentPlacementException;
import filemanager.exceptions.FileFormatException;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;

import static gui.UserInterface.showBoard;

public class WireworldWindow {
    private JPanel MainPanel;
    private JButton readFileButton;
    private JButton saveToFileButton;
    private JButton runStopButton;
    private JPanel Canvas;
    private JLabel pathReadFile;
    private JLabel pathSaveToFile;
    private JLabel numberOfIterations;
    private JSpinner numberOfIterationsChooser;
    private JButton numberOfIterationsAcceptance;
    private JLabel horizontalSpacer;
    private String filename;

    public WireworldWindow() {
        readFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                int decision = chooser.showOpenDialog(WireworldWindow.this.MainPanel);
                if (decision == JFileChooser.APPROVE_OPTION) {
                    File selected = chooser.getSelectedFile();
                    filename = selected.getAbsolutePath();
                    pathReadFile.setText(filename);
                }
            }
        });
        saveToFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                int decision = chooser.showOpenDialog(WireworldWindow.this.MainPanel);
                if (decision == JFileChooser.APPROVE_OPTION) {
                    File selected = chooser.getSelectedFile();
                    filename = selected.getAbsolutePath();
                    pathSaveToFile.setText(filename);
                }
            }
        });
        runStopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*try {
                    int numberOfIterations = (int) numberOfIterationsChooser.getValue();
                } catch (ClassCastException exception) {

                }*/
                System.out.println("tak");
                showBoard();
            }
        });
    }

    public JPanel getRootPanel() {
        return this.MainPanel;
    }

    private void createUIComponents() {
        this.Canvas = new WireworldCanvas();
    }


}
